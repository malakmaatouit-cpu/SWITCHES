# NetVision — Network Switch Monitor
## Application PHP de surveillance de switches réseau

---

## 📋 Installation

### Prérequis
- PHP 8.0+
- MySQL 5.7+ / MariaDB
- Apache / Nginx avec mod_rewrite
- Extension PHP: `pdo`, `pdo_mysql`

### Étapes

1. **Copier les fichiers** dans votre répertoire web:
   ```
   /var/www/html/switch-monitor/
   ```

2. **Créer la base de données** :
   ```bash
   mysql -u root -p < database.sql
   ```

3. **Configurer `config.php`** :
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'netvision');
   define('DB_USER', 'votre_user');
   define('DB_PASS', 'votre_password');
   ```

4. **Accéder à l'application** :
   ```
   http://localhost/switch-monitor/
   ```

---

## 🔐 Comptes de démonstration

| Utilisateur | Mot de passe | Rôle |
|---|---|---|
| `superadmin` | `password` | Super Admin |
| `admin_netcorp` | `password` | Admin |
| `operator1` | `password` | Opérateur |

> ⚠️ En production, changez immédiatement les mots de passe !

---

## 🏗 Structure des fichiers

```
switch-monitor/
├── index.php           # Application principale (routing + UI)
├── config.php          # Configuration
├── database.sql        # Schéma + données de démo
├── includes/
│   ├── db.php          # PDO + Auth class
│   └── monitor.php     # Ping + Métriques
└── api/
    └── switches.php    # API REST (AJAX)
```

---

## ✨ Fonctionnalités

### Surveillance
- ✅ Statut temps réel (online/offline/warning)
- ✅ Métriques live: CPU, RAM, Température
- ✅ Ping à la demande
- ✅ Uptime du switch
- ✅ Historique des métriques

### Ports
- ✅ Statut de chaque port (up/down/disabled)
- ✅ Vitesse, VLAN, Type (access/trunk/uplink)
- ✅ Appareil connecté + MAC
- ✅ Traffic IN/OUT

### Protocoles
- ✅ SNMP v2c/v3
- ✅ SSH v2
- ✅ STP / RSTP / MSTP
- ✅ LACP (802.3ad)
- ✅ LLDP (802.1AB)
- ✅ CDP
- ✅ OSPF
- ✅ BGP

### Gestion
- ✅ Multi-organisations
- ✅ Rôles: superadmin / admin / operator / viewer
- ✅ Alertes automatiques
- ✅ Topologie réseau visuelle
- ✅ Page visiteur (sans login)
- ✅ Audit log

---

## 🔌 En production: Intégration SNMP réelle

Remplacez dans `includes/monitor.php` la fonction `getMetrics()` par:

```php
// Utiliser les vraies fonctions SNMP PHP
$cpu = snmp2_get($ip, 'public', '.1.3.6.1.4.1.9.2.1.56.0'); // Cisco CPU OID
$temp = snmp2_get($ip, 'public', '.1.3.6.1.4.1.9.9.13.1.3.1.3.1');
```

OIDs utiles:
- CPU: `.1.3.6.1.4.1.9.2.1.56.0` (Cisco)
- Ports: `.1.3.6.1.2.1.2.2.1` (ifTable standard)
- Uptime: `.1.3.6.1.2.1.1.3.0`
- Temp: `.1.3.6.1.4.1.9.9.13.1.3.1.3`

---

## 🔄 Monitoring automatique (cron)

Ajoutez dans crontab pour surveiller toutes les minutes:

```cron
* * * * * php /var/www/html/switch-monitor/cron/monitor.php
```
