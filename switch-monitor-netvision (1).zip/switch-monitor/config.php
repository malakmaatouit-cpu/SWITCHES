<?php
// config.php - NetVision Configuration

define('DB_HOST', 'localhost');
define('DB_NAME', 'netvision');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'NetVision');
define('APP_VERSION', '2.1.0');
define('APP_URL', 'http://localhost/switch-monitor');

define('SESSION_TIMEOUT', 3600); // 1 hour
define('PING_TIMEOUT', 3); // seconds
define('MONITOR_INTERVAL', 60); // seconds

// Thresholds
define('TEMP_WARNING', 55);
define('TEMP_CRITICAL', 65);
define('CPU_WARNING', 70);
define('CPU_CRITICAL', 90);
define('MEM_WARNING', 75);
define('MEM_CRITICAL', 90);
