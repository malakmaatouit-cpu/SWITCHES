<?php
// includes/db.php
require_once __DIR__ . '/../config.php';

class Database {
    private static $pdo = null;

    public static function connect(): PDO {
        if (self::$pdo === null) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
            }
        }
        return self::$pdo;
    }

    public static function query(string $sql, array $params = []): PDOStatement {
        $stmt = self::connect()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function fetch(string $sql, array $params = []): ?array {
        return self::query($sql, $params)->fetch() ?: null;
    }

    public static function fetchAll(string $sql, array $params = []): array {
        return self::query($sql, $params)->fetchAll();
    }

    public static function insert(string $sql, array $params = []): int {
        self::query($sql, $params);
        return (int) self::connect()->lastInsertId();
    }
}

// includes/auth.php
class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function login(string $username, string $password): array {
        self::start();
        $user = Database::fetch(
            "SELECT u.*, o.name as org_name, o.slug as org_slug FROM users u 
             LEFT JOIN organizations o ON u.organization_id = o.id 
             WHERE (u.username = ? OR u.email = ?) AND u.is_active = 1",
            [$username, $username]
        );

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return ['success' => false, 'message' => 'Identifiants incorrects'];
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['org_id'] = $user['organization_id'];
        $_SESSION['org_name'] = $user['org_name'];
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();

        Database::query("UPDATE users SET last_login = NOW() WHERE id = ?", [$user['id']]);

        return ['success' => true, 'role' => $user['role']];
    }

    public static function logout(): void {
        self::start();
        session_destroy();
    }

    public static function check(): bool {
        self::start();
        if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) return false;
        if (time() - $_SESSION['login_time'] > SESSION_TIMEOUT) {
            self::logout();
            return false;
        }
        return true;
    }

    public static function require(string $minRole = 'viewer'): void {
        if (!self::check()) {
            header('Location: index.php?page=login');
            exit;
        }
        $roles = ['viewer' => 1, 'operator' => 2, 'admin' => 3, 'superadmin' => 4];
        if (($roles[$_SESSION['role']] ?? 0) < ($roles[$minRole] ?? 1)) {
            header('Location: index.php?page=dashboard&error=unauthorized');
            exit;
        }
    }

    public static function user(): array {
        self::start();
        return [
            'id' => $_SESSION['user_id'] ?? null,
            'username' => $_SESSION['username'] ?? null,
            'full_name' => $_SESSION['full_name'] ?? 'Visiteur',
            'role' => $_SESSION['role'] ?? 'visitor',
            'org_id' => $_SESSION['org_id'] ?? null,
            'org_name' => $_SESSION['org_name'] ?? null,
        ];
    }

    public static function is(string $role): bool {
        $roles = ['viewer' => 1, 'operator' => 2, 'admin' => 3, 'superadmin' => 4];
        $current = $roles[$_SESSION['role'] ?? 'viewer'] ?? 0;
        return $current >= ($roles[$role] ?? 99);
    }
}
