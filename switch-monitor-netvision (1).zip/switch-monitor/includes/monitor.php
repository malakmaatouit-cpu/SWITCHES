<?php
// includes/monitor.php

class SwitchMonitor {

    // Ping a host, return response time ms or false
    public static function ping(string $ip): int|false {
        $start = microtime(true);
        $fp = @fsockopen($ip, 80, $errno, $errstr, PING_TIMEOUT);
        if (!$fp) {
            // Try ICMP-style via exec
            $result = null;
            exec("ping -c 1 -W " . PING_TIMEOUT . " " . escapeshellarg($ip) . " 2>/dev/null", $output, $result);
            if ($result === 0) {
                // Extract time from ping output
                foreach ($output as $line) {
                    if (preg_match('/time[=<](\d+\.?\d*)\s*ms/', $line, $m)) {
                        return (int)$m[1];
                    }
                }
                return 1;
            }
            return false;
        }
        fclose($fp);
        return (int)((microtime(true) - $start) * 1000);
    }

    // Simulate SNMP-like data (in real app: use snmp_get functions)
    public static function getMetrics(array $switch): array {
        // In production: use snmp2_get() with real OIDs
        // Here we simulate dynamic data for demo
        $isOnline = ($switch['status'] === 'online' || $switch['status'] === 'warning');
        
        if (!$isOnline) {
            return [
                'status' => 'offline',
                'cpu' => 0, 'memory' => 0, 'temperature' => 0,
                'uptime' => 0, 'response_ms' => null
            ];
        }

        // Simulate slight fluctuation
        $cpu = max(0, min(100, $switch['cpu_usage'] + (rand(-5, 5))));
        $mem = max(0, min(100, $switch['memory_usage'] + (rand(-3, 3))));
        $temp = max(20, $switch['temperature'] + (rand(-2, 2) * 0.5));
        
        $status = 'online';
        if ($temp >= TEMP_CRITICAL || $cpu >= CPU_CRITICAL) $status = 'warning';
        if ($temp >= TEMP_CRITICAL + 10) $status = 'critical';

        return [
            'status' => $status,
            'cpu' => round($cpu, 1),
            'memory' => round($mem, 1),
            'temperature' => round($temp, 1),
            'uptime' => $switch['uptime_seconds'] + 60,
            'response_ms' => rand(1, 8)
        ];
    }

    public static function formatUptime(int $seconds): string {
        if ($seconds <= 0) return 'Offline';
        $days = floor($seconds / 86400);
        $hours = floor(($seconds % 86400) / 3600);
        $mins = floor(($seconds % 3600) / 60);
        if ($days > 0) return "{$days}j {$hours}h {$mins}m";
        if ($hours > 0) return "{$hours}h {$mins}m";
        return "{$mins}m";
    }

    public static function formatBytes(int $bytes): string {
        if ($bytes >= 1073741824) return round($bytes/1073741824, 2) . ' GB';
        if ($bytes >= 1048576) return round($bytes/1048576, 2) . ' MB';
        if ($bytes >= 1024) return round($bytes/1024, 2) . ' KB';
        return $bytes . ' B';
    }

    public static function getStatusColor(string $status): string {
        return match($status) {
            'online' => '#00d68f',
            'warning', 'critical' => '#ffaa00',
            'offline' => '#ff3d71',
            default => '#8f9bb3'
        };
    }

    public static function getStatusIcon(string $status): string {
        return match($status) {
            'online' => '●',
            'warning' => '▲',
            'offline' => '✕',
            default => '○'
        };
    }
}
