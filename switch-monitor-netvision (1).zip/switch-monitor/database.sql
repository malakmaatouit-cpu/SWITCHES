-- NetVision Switch Monitor Database
CREATE DATABASE IF NOT EXISTS netvision;
USE netvision;

-- Organizations
CREATE TABLE organizations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    logo_url VARCHAR(500),
    contact_email VARCHAR(255),
    contact_phone VARCHAR(50),
    address TEXT,
    subscription_plan ENUM('free','pro','enterprise') DEFAULT 'free',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role ENUM('superadmin','admin','operator','viewer') DEFAULT 'viewer',
    avatar_url VARCHAR(500),
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

-- Switches
CREATE TABLE switches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    hostname VARCHAR(255),
    ip_address VARCHAR(45) NOT NULL,
    mac_address VARCHAR(17),
    location VARCHAR(255),
    model VARCHAR(255),
    vendor VARCHAR(100),
    firmware_version VARCHAR(100),
    serial_number VARCHAR(100),
    num_ports INT DEFAULT 24,
    uplink_ports INT DEFAULT 2,
    snmp_community VARCHAR(100) DEFAULT 'public',
    snmp_version ENUM('v1','v2c','v3') DEFAULT 'v2c',
    ssh_port INT DEFAULT 22,
    ssh_username VARCHAR(100),
    ssh_password VARCHAR(255),
    status ENUM('online','offline','warning','unknown') DEFAULT 'unknown',
    cpu_usage FLOAT DEFAULT 0,
    memory_usage FLOAT DEFAULT 0,
    temperature FLOAT DEFAULT 0,
    uptime_seconds BIGINT DEFAULT 0,
    last_seen TIMESTAMP NULL,
    notes TEXT,
    tags VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

-- Switch Ports
CREATE TABLE switch_ports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    switch_id INT NOT NULL,
    port_number INT NOT NULL,
    port_name VARCHAR(100),
    description VARCHAR(255),
    status ENUM('up','down','disabled','error') DEFAULT 'unknown',
    speed VARCHAR(50),
    duplex ENUM('full','half','auto') DEFAULT 'auto',
    vlan_id INT DEFAULT 1,
    port_type ENUM('access','trunk','uplink') DEFAULT 'access',
    connected_device VARCHAR(255),
    connected_mac VARCHAR(17),
    bytes_in BIGINT DEFAULT 0,
    bytes_out BIGINT DEFAULT 0,
    errors_in INT DEFAULT 0,
    errors_out INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (switch_id) REFERENCES switches(id) ON DELETE CASCADE,
    UNIQUE KEY unique_port (switch_id, port_number)
);

-- Protocols per switch
CREATE TABLE switch_protocols (
    id INT AUTO_INCREMENT PRIMARY KEY,
    switch_id INT NOT NULL,
    protocol_name VARCHAR(100) NOT NULL,
    protocol_version VARCHAR(50),
    status ENUM('enabled','disabled','negotiating') DEFAULT 'disabled',
    details JSON,
    FOREIGN KEY (switch_id) REFERENCES switches(id) ON DELETE CASCADE
);

-- Monitoring History
CREATE TABLE monitoring_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    switch_id INT NOT NULL,
    status ENUM('online','offline','warning','unknown'),
    cpu_usage FLOAT,
    memory_usage FLOAT,
    temperature FLOAT,
    response_time_ms INT,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (switch_id) REFERENCES switches(id) ON DELETE CASCADE
);

-- Alerts
CREATE TABLE alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    switch_id INT,
    port_id INT,
    alert_type ENUM('offline','high_temp','high_cpu','port_down','port_error','uptime','custom') NOT NULL,
    severity ENUM('info','warning','critical') DEFAULT 'info',
    title VARCHAR(255) NOT NULL,
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (switch_id) REFERENCES switches(id) ON DELETE SET NULL
);

-- Audit Log
CREATE TABLE audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    organization_id INT,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id INT,
    details JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Insert demo data
INSERT INTO organizations (name, slug, contact_email, subscription_plan) VALUES 
('NetCorp Maroc', 'netcorp', 'admin@netcorp.ma', 'enterprise'),
('TechHub Casablanca', 'techhub', 'contact@techhub.ma', 'pro');

-- Password: Admin@123
INSERT INTO users (organization_id, username, email, password_hash, full_name, role) VALUES
(1, 'superadmin', 'super@netvision.ma', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Super Admin', 'superadmin'),
(1, 'admin_netcorp', 'admin@netcorp.ma', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mohammed Alami', 'admin'),
(1, 'operator1', 'operator@netcorp.ma', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Youssef Benali', 'operator');

-- Demo switches
INSERT INTO switches (organization_id, name, hostname, ip_address, mac_address, location, model, vendor, firmware_version, num_ports, status, cpu_usage, memory_usage, temperature, uptime_seconds) VALUES
(1, 'Core-Switch-01', 'core-sw-01.netcorp.local', '192.168.1.1', 'AA:BB:CC:DD:EE:01', 'Datacenter A - Rack 1', 'Catalyst 9300-24P', 'Cisco', '17.9.3', 24, 'online', 23.5, 45.2, 42.1, 8640000),
(1, 'Distribution-SW-02', 'dist-sw-02.netcorp.local', '192.168.1.2', 'AA:BB:CC:DD:EE:02', 'Floor 2 - Comms Room', 'EX2300-24P', 'Juniper', '22.4R1', 24, 'online', 18.3, 38.7, 38.5, 3456000),
(1, 'Access-SW-03', 'acc-sw-03.netcorp.local', '192.168.1.3', 'AA:BB:CC:DD:EE:03', 'Floor 3 - Office Wing A', 'S5735-L24P4X', 'Huawei', 'V200R022', 24, 'warning', 78.9, 82.4, 68.7, 172800),
(1, 'Access-SW-04', 'acc-sw-04.netcorp.local', '192.168.1.4', 'AA:BB:CC:DD:EE:04', 'Floor 1 - Reception', 'FS S3150-8T', 'FS.com', '2.1.2', 8, 'offline', 0, 0, 0, 0),
(1, 'Edge-SW-05', 'edge-sw-05.netcorp.local', '192.168.1.5', 'AA:BB:CC:DD:EE:05', 'Server Room - Rack 3', 'S6720-30C', 'H3C', 'R6700P01', 24, 'online', 31.2, 52.1, 44.3, 5184000);

-- Demo ports for switch 1
INSERT INTO switch_ports (switch_id, port_number, port_name, description, status, speed, vlan_id, port_type, connected_device, bytes_in, bytes_out) VALUES
(1, 1, 'Gi0/1', 'Uplink to Router', 'up', '1Gbps', 1, 'uplink', 'Router-01', 1524863, 987234),
(1, 2, 'Gi0/2', 'Server Farm Link', 'up', '1Gbps', 10, 'trunk', 'ESXi-Host-01', 8432156, 5621087),
(1, 3, 'Gi0/3', 'Storage Network', 'up', '10Gbps', 20, 'trunk', 'NAS-01', 15234876, 12876543),
(1, 4, 'Gi0/4', 'Backup Server', 'up', '1Gbps', 10, 'access', 'Backup-Srv-01', 2341876, 1987234),
(1, 5, 'Gi0/5', 'HR Department', 'down', '100Mbps', 30, 'access', NULL, 0, 0),
(1, 6, 'Gi0/6', 'IT Department', 'up', '1Gbps', 40, 'access', 'PC-IT-001', 456789, 234567),
(1, 7, 'Gi0/7', 'Management VLAN', 'up', '1Gbps', 99, 'access', 'Mgmt-Station', 123456, 98765),
(1, 8, 'Gi0/8', 'Security Cameras', 'up', '100Mbps', 50, 'access', 'NVR-01', 7654321, 123456),
(1, 9, 'Gi0/9', 'VoIP Phones', 'up', '100Mbps', 60, 'access', 'IP-Phone-Pool', 876543, 654321),
(1, 10, 'Gi0/10', 'WiFi AP Floor 1', 'up', '1Gbps', 70, 'trunk', 'AP-Aruba-01', 12345678, 9876543),
(1, 11, 'Gi0/11', 'Spare Port', 'disabled', NULL, 1, 'access', NULL, 0, 0),
(1, 12, 'Gi0/12', 'Printer Pool', 'down', '100Mbps', 30, 'access', NULL, 0, 0);

-- Protocols
INSERT INTO switch_protocols (switch_id, protocol_name, protocol_version, status) VALUES
(1, 'STP', '802.1D RSTP', 'enabled'),
(1, 'LACP', '802.3ad', 'enabled'),
(1, 'LLDP', '802.1AB', 'enabled'),
(1, 'CDP', 'v2', 'enabled'),
(1, 'OSPF', 'v2', 'disabled'),
(1, 'BGP', '4', 'disabled'),
(1, 'SNMP', 'v2c/v3', 'enabled'),
(1, 'SSH', 'v2', 'enabled'),
(2, 'STP', 'MSTP', 'enabled'),
(2, 'LLDP', '802.1AB', 'enabled'),
(2, 'OSPF', 'v2', 'enabled'),
(2, 'SNMP', 'v3', 'enabled'),
(3, 'STP', 'RSTP', 'enabled'),
(3, 'LLDP', '802.1AB', 'enabled'),
(3, 'SNMP', 'v2c', 'enabled'),
(5, 'STP', 'MSTP', 'enabled'),
(5, 'LACP', '802.3ad', 'enabled'),
(5, 'LLDP', '802.1AB', 'enabled'),
(5, 'OSPF', 'v2', 'enabled'),
(5, 'BGP', '4', 'enabled'),
(5, 'SNMP', 'v3', 'enabled');

-- Demo alerts
INSERT INTO alerts (organization_id, switch_id, alert_type, severity, title, message, is_read) VALUES
(1, 3, 'high_temp', 'critical', 'High Temperature on Access-SW-03', 'Temperature reached 68.7°C - Critical threshold exceeded', FALSE),
(1, 3, 'high_cpu', 'critical', 'High CPU Usage on Access-SW-03', 'CPU usage at 78.9% - Performance degraded', FALSE),
(1, 4, 'offline', 'critical', 'Switch Offline: Access-SW-04', 'Switch at 192.168.1.4 is unreachable since 2 hours', FALSE),
(1, 1, 'port_down', 'warning', 'Port Down on Core-Switch-01', 'Port Gi0/5 (HR Department) is down', TRUE),
(1, 1, 'port_down', 'info', 'Port Restored on Core-Switch-01', 'Port Gi0/6 (IT Department) is back online', TRUE);
