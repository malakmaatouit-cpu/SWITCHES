<?php
// api/switches.php - REST API for real-time data
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/monitor.php';
Auth::start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if (!Auth::check()) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user = Auth::user();
$action = $_GET['action'] ?? '';

switch ($action) {

    case 'list':
        $switches = Database::fetchAll(
            "SELECT s.*, o.name as org_name,
             (SELECT COUNT(*) FROM switch_ports WHERE switch_id = s.id AND status = 'up') as ports_up,
             (SELECT COUNT(*) FROM switch_ports WHERE switch_id = s.id) as ports_total,
             (SELECT COUNT(*) FROM alerts WHERE switch_id = s.id AND is_read = 0 AND is_resolved = 0) as unread_alerts
             FROM switches s
             LEFT JOIN organizations o ON s.organization_id = o.id
             WHERE s.organization_id = ?
             ORDER BY s.name",
            [$user['org_id']]
        );
        echo json_encode(['switches' => $switches]);
        break;

    case 'detail':
        $id = (int)($_GET['id'] ?? 0);
        $switch = Database::fetch(
            "SELECT s.*, o.name as org_name FROM switches s
             LEFT JOIN organizations o ON s.organization_id = o.id
             WHERE s.id = ? AND s.organization_id = ?",
            [$id, $user['org_id']]
        );
        if (!$switch) { echo json_encode(['error' => 'Not found']); break; }

        $ports = Database::fetchAll(
            "SELECT * FROM switch_ports WHERE switch_id = ? ORDER BY port_number",
            [$id]
        );
        $protocols = Database::fetchAll(
            "SELECT * FROM switch_protocols WHERE switch_id = ?",
            [$id]
        );
        $alerts = Database::fetchAll(
            "SELECT * FROM alerts WHERE switch_id = ? ORDER BY created_at DESC LIMIT 10",
            [$id]
        );
        $history = Database::fetchAll(
            "SELECT cpu_usage, memory_usage, temperature, response_time_ms, checked_at 
             FROM monitoring_history WHERE switch_id = ? ORDER BY checked_at DESC LIMIT 24",
            [$id]
        );

        // Simulate live metrics
        $metrics = SwitchMonitor::getMetrics($switch);
        $switch['live_cpu'] = $metrics['cpu'];
        $switch['live_memory'] = $metrics['memory'];
        $switch['live_temp'] = $metrics['temperature'];
        $switch['uptime_formatted'] = SwitchMonitor::formatUptime($switch['uptime_seconds']);

        echo json_encode([
            'switch' => $switch,
            'ports' => $ports,
            'protocols' => $protocols,
            'alerts' => $alerts,
            'history' => array_reverse($history)
        ]);
        break;

    case 'ping':
        $id = (int)($_GET['id'] ?? 0);
        $switch = Database::fetch("SELECT ip_address, name FROM switches WHERE id = ? AND organization_id = ?", [$id, $user['org_id']]);
        if (!$switch) { echo json_encode(['error' => 'Not found']); break; }
        
        $ms = SwitchMonitor::ping($switch['ip_address']);
        echo json_encode([
            'reachable' => $ms !== false,
            'response_ms' => $ms,
            'ip' => $switch['ip_address']
        ]);
        break;

    case 'live_metrics':
        $id = (int)($_GET['id'] ?? 0);
        $switch = Database::fetch("SELECT * FROM switches WHERE id = ? AND organization_id = ?", [$id, $user['org_id']]);
        if (!$switch) { echo json_encode(['error' => 'Not found']); break; }
        $metrics = SwitchMonitor::getMetrics($switch);
        $metrics['uptime_formatted'] = SwitchMonitor::formatUptime($metrics['uptime']);
        echo json_encode($metrics);
        break;

    case 'alerts':
        $alerts = Database::fetchAll(
            "SELECT a.*, s.name as switch_name, s.ip_address 
             FROM alerts a
             LEFT JOIN switches s ON a.switch_id = s.id
             WHERE a.organization_id = ? AND a.is_resolved = 0
             ORDER BY a.created_at DESC LIMIT 50",
            [$user['org_id']]
        );
        $unread = Database::fetch("SELECT COUNT(*) as cnt FROM alerts WHERE organization_id = ? AND is_read = 0 AND is_resolved = 0", [$user['org_id']]);
        echo json_encode(['alerts' => $alerts, 'unread_count' => $unread['cnt']]);
        break;

    case 'mark_alert_read':
        if (!Auth::is('operator')) { echo json_encode(['error' => 'Forbidden']); break; }
        $id = (int)($_POST['id'] ?? 0);
        Database::query("UPDATE alerts SET is_read = 1 WHERE id = ? AND organization_id = ?", [$id, $user['org_id']]);
        echo json_encode(['success' => true]);
        break;

    case 'stats':
        $total = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ?", [$user['org_id']]);
        $online = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'online'", [$user['org_id']]);
        $offline = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'offline'", [$user['org_id']]);
        $warning = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'warning'", [$user['org_id']]);
        $totalPorts = Database::fetch("SELECT COUNT(*) as cnt FROM switch_ports sp JOIN switches s ON sp.switch_id = s.id WHERE s.organization_id = ?", [$user['org_id']]);
        $portsUp = Database::fetch("SELECT COUNT(*) as cnt FROM switch_ports sp JOIN switches s ON sp.switch_id = s.id WHERE s.organization_id = ? AND sp.status = 'up'", [$user['org_id']]);
        $critAlerts = Database::fetch("SELECT COUNT(*) as cnt FROM alerts WHERE organization_id = ? AND severity = 'critical' AND is_resolved = 0", [$user['org_id']]);
        echo json_encode([
            'total_switches' => $total['cnt'],
            'online' => $online['cnt'],
            'offline' => $offline['cnt'],
            'warning' => $warning['cnt'],
            'total_ports' => $totalPorts['cnt'],
            'ports_up' => $portsUp['cnt'],
            'critical_alerts' => $critAlerts['cnt'],
        ]);
        break;

    case 'save_switch':
        if (!Auth::is('admin')) { echo json_encode(['error' => 'Forbidden']); break; }
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? 0);
        if ($id) {
            Database::query(
                "UPDATE switches SET name=?, ip_address=?, location=?, model=?, vendor=?, num_ports=?, notes=? WHERE id=? AND organization_id=?",
                [$data['name'], $data['ip_address'], $data['location'], $data['model'], $data['vendor'], $data['num_ports'], $data['notes'], $id, $user['org_id']]
            );
        } else {
            $id = Database::insert(
                "INSERT INTO switches (organization_id, name, ip_address, location, model, vendor, num_ports, notes, status) VALUES (?,?,?,?,?,?,?,?,'unknown')",
                [$user['org_id'], $data['name'], $data['ip_address'], $data['location'], $data['model'], $data['vendor'], $data['num_ports'] ?? 24, $data['notes']]
            );
        }
        echo json_encode(['success' => true, 'id' => $id]);
        break;

    case 'delete_switch':
        if (!Auth::is('admin')) { echo json_encode(['error' => 'Forbidden']); break; }
        $id = (int)($_POST['id'] ?? 0);
        Database::query("DELETE FROM switches WHERE id = ? AND organization_id = ?", [$id, $user['org_id']]);
        echo json_encode(['success' => true]);
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}
