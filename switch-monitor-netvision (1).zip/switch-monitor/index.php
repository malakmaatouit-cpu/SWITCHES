<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/monitor.php';

Auth::start();
$page = $_GET['page'] ?? (Auth::check() ? 'dashboard' : 'login');

// Handle login POST
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $result = Auth::login($_POST['username'] ?? '', $_POST['password'] ?? '');
    if ($result['success']) {
        header('Location: index.php?page=dashboard');
        exit;
    } else {
        $loginError = $result['message'];
        $page = 'login';
    }
}

// Handle logout
if ($page === 'logout') {
    Auth::logout();
    header('Location: index.php?page=login');
    exit;
}

// Auth guard for protected pages
$publicPages = ['login', 'visitor'];
if (!in_array($page, $publicPages) && !Auth::check()) {
    header('Location: index.php?page=login');
    exit;
}

$user = Auth::user();

// Load data for pages
$switches = [];
$stats = [];
$alerts = [];
$organizations = [];

if (Auth::check()) {
    $switches = Database::fetchAll(
        "SELECT s.*, 
         (SELECT COUNT(*) FROM switch_ports WHERE switch_id = s.id AND status = 'up') as ports_up,
         (SELECT COUNT(*) FROM switch_ports WHERE switch_id = s.id) as ports_total,
         (SELECT COUNT(*) FROM alerts WHERE switch_id = s.id AND is_read = 0 AND is_resolved = 0) as unread_alerts
         FROM switches s WHERE s.organization_id = ? ORDER BY s.name",
        [$user['org_id']]
    );

    $total = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ?", [$user['org_id']]);
    $online = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'online'", [$user['org_id']]);
    $offline = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'offline'", [$user['org_id']]);
    $warning = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ? AND status = 'warning'", [$user['org_id']]);
    $critAlerts = Database::fetch("SELECT COUNT(*) as cnt FROM alerts WHERE organization_id = ? AND severity = 'critical' AND is_resolved = 0", [$user['org_id']]);

    $stats = [
        'total' => $total['cnt'] ?? 0,
        'online' => $online['cnt'] ?? 0,
        'offline' => $offline['cnt'] ?? 0,
        'warning' => $warning['cnt'] ?? 0,
        'critical_alerts' => $critAlerts['cnt'] ?? 0,
    ];

    $alerts = Database::fetchAll(
        "SELECT a.*, s.name as switch_name FROM alerts a
         LEFT JOIN switches s ON a.switch_id = s.id
         WHERE a.organization_id = ? AND a.is_resolved = 0
         ORDER BY a.created_at DESC LIMIT 20",
        [$user['org_id']]
    );

    if ($user['role'] === 'superadmin') {
        $organizations = Database::fetchAll("SELECT * FROM organizations ORDER BY name");
    }
}

// Selected switch for detail view
$selectedSwitch = null;
$selectedPorts = [];
$selectedProtocols = [];
if ($page === 'switch_detail' && isset($_GET['id'])) {
    $switchId = (int)$_GET['id'];
    $selectedSwitch = Database::fetch(
        "SELECT s.*, o.name as org_name FROM switches s LEFT JOIN organizations o ON s.organization_id = o.id WHERE s.id = ? AND s.organization_id = ?",
        [$switchId, $user['org_id']]
    );
    if ($selectedSwitch) {
        $selectedPorts = Database::fetchAll("SELECT * FROM switch_ports WHERE switch_id = ? ORDER BY port_number", [$switchId]);
        $selectedProtocols = Database::fetchAll("SELECT * FROM switch_protocols WHERE switch_id = ?", [$switchId]);
        $selectedAlerts = Database::fetchAll("SELECT * FROM alerts WHERE switch_id = ? ORDER BY created_at DESC LIMIT 10", [$switchId]);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NetVision — Network Switch Monitor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #070b14;
    --bg2: #0d1421;
    --bg3: #111b2e;
    --bg4: #172035;
    --border: #1e2d47;
    --border2: #243550;
    --text: #e2eaf8;
    --text2: #8fa3c4;
    --text3: #4e6585;
    --accent: #00aeff;
    --accent2: #0070cc;
    --green: #00d68f;
    --yellow: #ffaa00;
    --red: #ff3d71;
    --purple: #b8a4ff;
    --cyan: #00e5ff;
    --mono: 'IBM Plex Mono', monospace;
    --sans: 'IBM Plex Sans', sans-serif;
    --radius: 8px;
    --shadow: 0 4px 24px rgba(0,0,0,0.4);
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--sans); min-height: 100vh; }

  /* === SCROLLBAR === */
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: var(--bg2); }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 3px; }

  /* === LAYOUT === */
  .app-layout { display: flex; min-height: 100vh; }
  .sidebar {
    width: 240px; background: var(--bg2); border-right: 1px solid var(--border);
    display: flex; flex-direction: column; position: fixed; top: 0; left: 0; height: 100vh; z-index: 100;
  }
  .main-content { margin-left: 240px; flex: 1; display: flex; flex-direction: column; }
  .topbar {
    background: var(--bg2); border-bottom: 1px solid var(--border);
    padding: 0 24px; height: 56px; display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 50;
  }
  .page-content { padding: 24px; flex: 1; }

  /* === SIDEBAR === */
  .sidebar-logo {
    padding: 20px 20px 16px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 10px;
  }
  .logo-icon {
    width: 32px; height: 32px; background: var(--accent); border-radius: 6px;
    display: flex; align-items: center; justify-content: center; font-size: 16px;
  }
  .logo-text { font-weight: 700; font-size: 18px; letter-spacing: -0.5px; }
  .logo-version { font-size: 10px; color: var(--text3); font-family: var(--mono); }

  .sidebar-nav { flex: 1; padding: 12px 0; overflow-y: auto; }
  .nav-section { padding: 4px 0; }
  .nav-label { font-size: 10px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: 1px; padding: 8px 20px 4px; }
  .nav-item {
    display: flex; align-items: center; gap: 10px; padding: 9px 20px; cursor: pointer;
    color: var(--text2); font-size: 13.5px; font-weight: 500; text-decoration: none;
    transition: all 0.15s; position: relative; border-left: 3px solid transparent;
  }
  .nav-item:hover { background: var(--bg3); color: var(--text); }
  .nav-item.active { background: rgba(0,174,255,0.08); color: var(--accent); border-left-color: var(--accent); }
  .nav-item .nav-icon { width: 16px; text-align: center; font-size: 14px; }
  .nav-badge {
    margin-left: auto; background: var(--red); color: white; font-size: 10px;
    font-weight: 700; padding: 1px 6px; border-radius: 10px; font-family: var(--mono);
  }
  .nav-badge.yellow { background: var(--yellow); color: #000; }

  .sidebar-user {
    padding: 14px 20px; border-top: 1px solid var(--border);
    display: flex; align-items: center; gap: 10px;
  }
  .user-avatar {
    width: 32px; height: 32px; border-radius: 50%; background: var(--accent2);
    display: flex; align-items: center; justify-content: center; font-weight: 700;
    font-size: 13px; flex-shrink: 0;
  }
  .user-info { flex: 1; min-width: 0; }
  .user-name { font-size: 12.5px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .user-role { font-size: 10px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.5px; }
  .role-badge {
    display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9px;
    font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
  }
  .role-superadmin { background: rgba(184,164,255,0.2); color: var(--purple); }
  .role-admin { background: rgba(0,174,255,0.2); color: var(--accent); }
  .role-operator { background: rgba(0,214,143,0.2); color: var(--green); }
  .role-viewer { background: rgba(143,163,196,0.2); color: var(--text2); }

  /* === TOPBAR === */
  .topbar-title { font-size: 15px; font-weight: 600; }
  .topbar-right { display: flex; align-items: center; gap: 16px; }
  .topbar-btn {
    background: none; border: 1px solid var(--border); color: var(--text2); padding: 6px 14px;
    border-radius: 6px; cursor: pointer; font-size: 12.5px; font-family: var(--sans);
    display: flex; align-items: center; gap: 6px; transition: all 0.15s;
  }
  .topbar-btn:hover { border-color: var(--accent); color: var(--accent); }
  .alert-bell { position: relative; cursor: pointer; color: var(--text2); font-size: 18px; padding: 4px; }
  .alert-dot {
    position: absolute; top: 0; right: 0; width: 8px; height: 8px;
    background: var(--red); border-radius: 50%; border: 2px solid var(--bg2);
  }

  /* === CARDS === */
  .card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius);
    overflow: hidden;
  }
  .card-header {
    padding: 16px 20px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between;
  }
  .card-title { font-size: 13px; font-weight: 600; color: var(--text2); text-transform: uppercase; letter-spacing: 0.5px; }
  .card-body { padding: 20px; }

  /* === STAT CARDS === */
  .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .stat-card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 20px; position: relative; overflow: hidden; transition: border-color 0.2s;
  }
  .stat-card:hover { border-color: var(--border2); }
  .stat-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  }
  .stat-card.green::before { background: var(--green); }
  .stat-card.red::before { background: var(--red); }
  .stat-card.yellow::before { background: var(--yellow); }
  .stat-card.blue::before { background: var(--accent); }
  .stat-label { font-size: 11px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 8px; }
  .stat-value { font-size: 36px; font-weight: 700; font-family: var(--mono); line-height: 1; }
  .stat-card.green .stat-value { color: var(--green); }
  .stat-card.red .stat-value { color: var(--red); }
  .stat-card.yellow .stat-value { color: var(--yellow); }
  .stat-card.blue .stat-value { color: var(--accent); }
  .stat-sub { font-size: 11px; color: var(--text3); margin-top: 6px; }

  /* === SWITCH GRID === */
  .switch-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px; }
  .switch-card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 18px; cursor: pointer; transition: all 0.2s; position: relative; overflow: hidden;
  }
  .switch-card:hover { border-color: var(--accent); transform: translateY(-1px); box-shadow: var(--shadow); }
  .switch-card.status-offline { border-left: 3px solid var(--red); }
  .switch-card.status-warning { border-left: 3px solid var(--yellow); }
  .switch-card.status-online { border-left: 3px solid var(--green); }

  .switch-card-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 14px; }
  .switch-card-name { font-size: 15px; font-weight: 600; margin-bottom: 3px; }
  .switch-card-ip { font-size: 11.5px; color: var(--accent); font-family: var(--mono); }
  .status-pill {
    display: flex; align-items: center; gap: 5px; padding: 3px 10px; border-radius: 20px;
    font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap;
  }
  .status-pill.online { background: rgba(0,214,143,0.12); color: var(--green); }
  .status-pill.offline { background: rgba(255,61,113,0.12); color: var(--red); }
  .status-pill.warning { background: rgba(255,170,0,0.12); color: var(--yellow); }
  .status-pulse { width: 6px; height: 6px; border-radius: 50%; animation: pulse 1.5s infinite; }
  .online .status-pulse { background: var(--green); }
  .offline .status-pulse { background: var(--red); animation: none; }
  .warning .status-pulse { background: var(--yellow); }
  @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }

  .switch-metrics { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px; }
  .metric-item { text-align: center; }
  .metric-label { font-size: 9px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }
  .metric-value { font-size: 18px; font-weight: 700; font-family: var(--mono); }
  .metric-value.good { color: var(--green); }
  .metric-value.warn { color: var(--yellow); }
  .metric-value.crit { color: var(--red); }
  .metric-value.off { color: var(--text3); }

  .switch-ports-bar { margin-bottom: 14px; }
  .ports-label { font-size: 11px; color: var(--text2); margin-bottom: 6px; display: flex; justify-content: space-between; }
  .ports-track { height: 5px; background: var(--bg3); border-radius: 3px; overflow: hidden; display: flex; gap: 1px; }
  .ports-track-fill { height: 100%; background: var(--green); border-radius: 3px; transition: width 0.5s; }
  .switch-card-footer { display: flex; align-items: center; justify-content: space-between; }
  .switch-meta { font-size: 11px; color: var(--text3); }
  .switch-location { font-size: 11px; color: var(--text2); }
  .detail-btn {
    background: var(--bg3); border: 1px solid var(--border); color: var(--text2); padding: 5px 14px;
    border-radius: 5px; cursor: pointer; font-size: 12px; font-family: var(--sans);
    text-decoration: none; transition: all 0.15s; display: inline-block;
  }
  .detail-btn:hover { background: var(--accent); border-color: var(--accent); color: white; }

  /* === SWITCH DETAIL === */
  .detail-header {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 24px; margin-bottom: 20px;
  }
  .detail-name { font-size: 26px; font-weight: 700; margin-bottom: 4px; }
  .detail-sub { font-size: 13px; color: var(--text2); font-family: var(--mono); }
  .detail-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-top: 20px; }

  .live-metric {
    background: var(--bg3); border: 1px solid var(--border); border-radius: 6px;
    padding: 16px; text-align: center;
  }
  .live-metric-label { font-size: 10px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 8px; }
  .live-metric-value { font-size: 32px; font-weight: 700; font-family: var(--mono); }
  .live-metric-unit { font-size: 13px; color: var(--text3); }
  .gauge-bar {
    height: 4px; background: var(--bg); border-radius: 2px; margin-top: 8px; overflow: hidden;
  }
  .gauge-fill { height: 100%; border-radius: 2px; transition: width 0.5s, background 0.5s; }

  /* === PORTS TABLE === */
  .ports-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .ports-table th {
    text-align: left; padding: 10px 14px; border-bottom: 1px solid var(--border);
    font-size: 10px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; font-weight: 600;
  }
  .ports-table td { padding: 10px 14px; border-bottom: 1px solid rgba(30,45,71,0.5); }
  .ports-table tr:hover td { background: rgba(255,255,255,0.02); }
  .port-status-dot {
    width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 6px; vertical-align: middle;
  }
  .port-up { background: var(--green); }
  .port-down { background: var(--red); }
  .port-disabled { background: var(--text3); }
  .port-number { font-family: var(--mono); color: var(--accent); }
  .port-name { font-family: var(--mono); font-size: 12px; }

  /* === PROTOCOLS === */
  .proto-grid { display: flex; flex-wrap: wrap; gap: 8px; }
  .proto-badge {
    display: flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 6px;
    font-size: 12px; font-weight: 600; font-family: var(--mono); border: 1px solid;
  }
  .proto-enabled { background: rgba(0,214,143,0.08); color: var(--green); border-color: rgba(0,214,143,0.2); }
  .proto-disabled { background: rgba(78,101,133,0.1); color: var(--text3); border-color: var(--border); }
  .proto-dot { width: 6px; height: 6px; border-radius: 50%; }
  .proto-enabled .proto-dot { background: var(--green); }
  .proto-disabled .proto-dot { background: var(--text3); }

  /* === ALERTS === */
  .alert-item {
    display: flex; align-items: flex-start; gap: 12px; padding: 12px 0;
    border-bottom: 1px solid rgba(30,45,71,0.5);
  }
  .alert-item:last-child { border-bottom: none; }
  .alert-icon { font-size: 16px; flex-shrink: 0; margin-top: 1px; }
  .alert-title { font-size: 13px; font-weight: 600; margin-bottom: 2px; }
  .alert-msg { font-size: 12px; color: var(--text2); }
  .alert-time { font-size: 10px; color: var(--text3); margin-top: 3px; font-family: var(--mono); }
  .sev-critical { color: var(--red); }
  .sev-warning { color: var(--yellow); }
  .sev-info { color: var(--accent); }

  /* === LOGIN PAGE === */
  .login-page {
    min-height: 100vh; background: var(--bg); display: flex; align-items: center; justify-content: center;
    position: relative; overflow: hidden;
  }
  .login-bg {
    position: absolute; inset: 0; overflow: hidden; z-index: 0;
    background: radial-gradient(ellipse at 20% 50%, rgba(0,174,255,0.05) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 50%, rgba(0,229,255,0.03) 0%, transparent 60%);
  }
  .login-grid {
    position: absolute; inset: 0;
    background-image: linear-gradient(var(--border) 1px, transparent 1px),
                      linear-gradient(90deg, var(--border) 1px, transparent 1px);
    background-size: 40px 40px; opacity: 0.3;
    mask-image: radial-gradient(ellipse at center, black 20%, transparent 70%);
  }
  .login-box {
    background: var(--bg2); border: 1px solid var(--border2); border-radius: 12px;
    padding: 40px; width: 420px; position: relative; z-index: 1;
    box-shadow: 0 20px 60px rgba(0,0,0,0.6);
  }
  .login-logo { text-align: center; margin-bottom: 32px; }
  .login-logo-icon {
    width: 56px; height: 56px; background: linear-gradient(135deg, var(--accent), var(--cyan));
    border-radius: 14px; display: inline-flex; align-items: center; justify-content: center;
    font-size: 26px; margin-bottom: 12px; box-shadow: 0 8px 24px rgba(0,174,255,0.3);
  }
  .login-title { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
  .login-sub { font-size: 13px; color: var(--text3); }
  .form-group { margin-bottom: 16px; }
  .form-label { font-size: 11px; font-weight: 600; color: var(--text2); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 6px; display: block; }
  .form-input {
    width: 100%; background: var(--bg3); border: 1px solid var(--border); color: var(--text);
    padding: 10px 14px; border-radius: 6px; font-size: 14px; font-family: var(--sans);
    transition: border-color 0.15s; outline: none;
  }
  .form-input:focus { border-color: var(--accent); }
  .btn-primary {
    width: 100%; background: var(--accent); color: white; border: none; padding: 12px;
    border-radius: 6px; font-size: 14px; font-weight: 600; font-family: var(--sans);
    cursor: pointer; transition: all 0.15s; letter-spacing: 0.3px;
  }
  .btn-primary:hover { background: var(--accent2); }
  .error-msg { background: rgba(255,61,113,0.1); border: 1px solid rgba(255,61,113,0.3); color: var(--red); padding: 10px 14px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; }
  .visitor-link { text-align: center; margin-top: 16px; font-size: 12px; color: var(--text3); }
  .visitor-link a { color: var(--accent); text-decoration: none; }

  /* === VISITOR === */
  .visitor-banner {
    background: linear-gradient(135deg, rgba(0,174,255,0.1), rgba(0,229,255,0.05));
    border: 1px solid rgba(0,174,255,0.2); border-radius: var(--radius); padding: 16px 20px;
    margin-bottom: 24px; display: flex; align-items: center; gap: 12px;
  }
  .visitor-icon { font-size: 24px; }
  .visitor-text { font-size: 13px; color: var(--text2); }
  .visitor-text strong { color: var(--accent); }

  /* === INFO TABLE === */
  .info-table { width: 100%; border-collapse: collapse; }
  .info-table tr td:first-child { font-size: 11px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.5px; width: 40%; padding: 8px 0; }
  .info-table tr td:last-child { font-size: 13px; font-family: var(--mono); color: var(--text); }

  /* === ORGANIZATIONS PAGE === */
  .org-card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 20px; display: flex; align-items: center; gap: 16px;
  }
  .org-logo { width: 48px; height: 48px; background: var(--bg4); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 22px; }
  .plan-badge {
    padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase;
  }
  .plan-enterprise { background: rgba(184,164,255,0.15); color: var(--purple); }
  .plan-pro { background: rgba(0,174,255,0.15); color: var(--accent); }
  .plan-free { background: rgba(143,163,196,0.1); color: var(--text2); }

  /* === GRID HELPERS === */
  .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .three-col { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
  .section-title { font-size: 11px; font-weight: 600; color: var(--text3); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 12px; }
  .mb16 { margin-bottom: 16px; }
  .mb24 { margin-bottom: 24px; }
  .mt16 { margin-top: 16px; }
  .flex { display: flex; }
  .items-center { align-items: center; }
  .justify-between { justify-content: space-between; }
  .gap8 { gap: 8px; }
  .gap16 { gap: 16px; }

  /* === MODAL === */
  .modal-overlay {
    position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 200;
    display: none; align-items: center; justify-content: center;
  }
  .modal-overlay.open { display: flex; }
  .modal {
    background: var(--bg2); border: 1px solid var(--border2); border-radius: 10px;
    width: 560px; max-width: 95vw; max-height: 90vh; overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.6);
  }
  .modal-header { padding: 20px 24px 16px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
  .modal-title { font-size: 16px; font-weight: 700; }
  .modal-close { background: none; border: none; color: var(--text3); font-size: 20px; cursor: pointer; line-height: 1; }
  .modal-close:hover { color: var(--text); }
  .modal-body { padding: 20px 24px 24px; }

  /* === RESPONSIVE BACK BTN === */
  .back-btn {
    display: inline-flex; align-items: center; gap: 6px; color: var(--text2); text-decoration: none;
    font-size: 13px; margin-bottom: 20px; padding: 6px 12px; background: var(--bg2);
    border: 1px solid var(--border); border-radius: 6px; transition: all 0.15s;
  }
  .back-btn:hover { color: var(--accent); border-color: var(--accent); }

  /* === MINI CHART === */
  .mini-chart { height: 40px; display: flex; align-items: flex-end; gap: 2px; }
  .mini-bar { flex: 1; border-radius: 2px 2px 0 0; min-height: 2px; transition: height 0.3s; }

  @media (max-width: 900px) {
    .sidebar { width: 200px; }
    .main-content { margin-left: 200px; }
    .detail-grid { grid-template-columns: 1fr 1fr; }
  }
  @media (max-width: 600px) {
    .sidebar { display: none; }
    .main-content { margin-left: 0; }
  }
</style>
</head>
<body>

<?php if ($page === 'login'): ?>
<!-- =================== LOGIN PAGE =================== -->
<div class="login-page">
  <div class="login-bg"><div class="login-grid"></div></div>
  <div class="login-box">
    <div class="login-logo">
      <div class="login-logo-icon">🔀</div>
      <div class="login-title">NetVision</div>
      <div class="login-sub">Network Switch Monitor Platform</div>
    </div>
    <?php if ($loginError): ?>
      <div class="error-msg">⚠ <?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST" action="?page=login">
      <div class="form-group">
        <label class="form-label">Username / Email</label>
        <input type="text" name="username" class="form-input" placeholder="admin_netcorp" required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-input" placeholder="••••••••" required>
      </div>
      <button type="submit" name="login" class="btn-primary">🔐 Connexion</button>
    </form>
    <div class="visitor-link">
      <a href="?page=visitor">👁 Accès visiteur (sans compte)</a>
    </div>
    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border);font-size:11px;color:var(--text3);text-align:center;">
      Demo: <code style="color:var(--accent)">admin_netcorp</code> / <code style="color:var(--accent)">password</code>
    </div>
  </div>
</div>

<?php elseif ($page === 'visitor'): ?>
<!-- =================== VISITOR PAGE =================== -->
<div class="login-page" style="align-items: flex-start; padding: 40px 20px;">
  <div style="width: 100%; max-width: 900px; margin: 0 auto; position: relative; z-index: 1;">
    <div class="login-bg"><div class="login-grid"></div></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <div style="display:flex;align-items:center;gap:10px;">
        <div class="login-logo-icon" style="width:40px;height:40px;font-size:20px;">🔀</div>
        <div>
          <div style="font-size:20px;font-weight:700;">NetVision</div>
          <div style="font-size:11px;color:var(--text3);">Mode Visiteur</div>
        </div>
      </div>
      <a href="?page=login" class="topbar-btn">🔐 Se connecter</a>
    </div>
    <div class="visitor-banner">
      <div class="visitor-icon">👁</div>
      <div class="visitor-text">Vous êtes en <strong>mode visiteur</strong> — accès lecture seule aux informations publiques. Connectez-vous pour accéder au monitoring complet.</div>
    </div>
    <div class="stat-grid">
      <div class="stat-card blue"><div class="stat-label">Plateforme</div><div class="stat-value" style="font-size:20px;">NetVision v2.1</div><div class="stat-sub">Network Monitor</div></div>
      <div class="stat-card green"><div class="stat-label">Uptime Garanti</div><div class="stat-value">99.9%</div><div class="stat-sub">SLA Enterprise</div></div>
      <div class="stat-card blue"><div class="stat-label">Protocoles</div><div class="stat-value">12+</div><div class="stat-sub">SNMP, SSH, LLDP...</div></div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-title">🏢 Fonctionnalités NetVision</span></div>
      <div class="card-body">
        <div class="two-col" style="gap:24px;">
          <div>
            <div class="section-title mb16">Monitoring Réseau</div>
            <?php foreach(['Surveillance temps réel des switches','Ping automatique & détection offline','Monitoring CPU / RAM / Température','Statut de tous les ports (up/down)','Graphiques historiques de performance','Alertes automatiques par seuils'] as $f): ?>
              <div style="padding:6px 0;border-bottom:1px solid var(--border);font-size:13px;color:var(--text2);">
                <span style="color:var(--green)">✓</span> <?= $f ?>
              </div>
            <?php endforeach; ?>
          </div>
          <div>
            <div class="section-title mb16">Gestion & Administration</div>
            <?php foreach(['Multi-organisations','Gestion des rôles (Admin/Opérateur)','Inventaire complet des équipements','Détection protocoles (LLDP, STP, BGP...)','Logs d\'audit complets','Export PDF/CSV des rapports'] as $f): ?>
              <div style="padding:6px 0;border-bottom:1px solid var(--border);font-size:13px;color:var(--text2);">
                <span style="color:var(--green)">✓</span> <?= $f ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
    <div style="text-align:center;margin-top:24px;">
      <a href="?page=login" class="btn-primary" style="display:inline-block;width:auto;padding:12px 32px;text-decoration:none;">🔐 Accéder à la plateforme</a>
    </div>
  </div>
</div>

<?php else: ?>
<!-- =================== MAIN APP =================== -->
<div class="app-layout">
  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">🔀</div>
      <div>
        <div class="logo-text">NetVision</div>
        <div class="logo-version">v<?= APP_VERSION ?></div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section">
        <div class="nav-label">Principal</div>
        <a href="?page=dashboard" class="nav-item <?= $page==='dashboard'?'active':'' ?>">
          <span class="nav-icon">⊞</span> Tableau de bord
        </a>
        <a href="?page=switches" class="nav-item <?= $page==='switches'||$page==='switch_detail'?'active':'' ?>">
          <span class="nav-icon">🔀</span> Switches
          <?php if(($stats['offline']??0)>0): ?>
            <span class="nav-badge"><?= $stats['offline'] ?></span>
          <?php endif; ?>
        </a>
        <a href="?page=alerts" class="nav-item <?= $page==='alerts'?'active':'' ?>">
          <span class="nav-icon">🔔</span> Alertes
          <?php $unreadAlerts = array_filter($alerts, fn($a) => !$a['is_read']); ?>
          <?php if(count($unreadAlerts)>0): ?>
            <span class="nav-badge"><?= count($unreadAlerts) ?></span>
          <?php endif; ?>
        </a>
      </div>
      <div class="nav-section">
        <div class="nav-label">Réseau</div>
        <a href="?page=topology" class="nav-item <?= $page==='topology'?'active':'' ?>">
          <span class="nav-icon">◈</span> Topologie
        </a>
        <a href="?page=protocols" class="nav-item <?= $page==='protocols'?'active':'' ?>">
          <span class="nav-icon">⟳</span> Protocoles
        </a>
      </div>
      <?php if(Auth::is('admin')): ?>
      <div class="nav-section">
        <div class="nav-label">Administration</div>
        <a href="?page=users" class="nav-item <?= $page==='users'?'active':'' ?>">
          <span class="nav-icon">👤</span> Utilisateurs
        </a>
        <?php if($user['role']==='superadmin'): ?>
        <a href="?page=organizations" class="nav-item <?= $page==='organizations'?'active':'' ?>">
          <span class="nav-icon">🏢</span> Organisations
        </a>
        <?php endif; ?>
        <a href="?page=settings" class="nav-item <?= $page==='settings'?'active':'' ?>">
          <span class="nav-icon">⚙</span> Paramètres
        </a>
      </div>
      <?php endif; ?>
    </nav>
    <div class="sidebar-user">
      <div class="user-avatar"><?= strtoupper(substr($user['full_name']??'U', 0, 1)) ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['full_name']??'') ?></div>
        <span class="role-badge role-<?= $user['role'] ?>"><?= $user['role'] ?></span>
      </div>
    </div>
  </aside>

  <!-- MAIN -->
  <div class="main-content">
    <header class="topbar">
      <div class="topbar-title">
        <?php $titles = ['dashboard'=>'Tableau de Bord','switches'=>'Switches','switch_detail'=>'Détail Switch','alerts'=>'Alertes','topology'=>'Topologie','protocols'=>'Protocoles','users'=>'Utilisateurs','organizations'=>'Organisations','settings'=>'Paramètres']; ?>
        <?= $titles[$page] ?? 'NetVision' ?>
      </div>
      <div class="topbar-right">
        <div style="font-size:12px;color:var(--text3);">
          🏢 <?= htmlspecialchars($user['org_name'] ?? '') ?>
        </div>
        <?php if(count($unreadAlerts??[])>0): ?>
        <a href="?page=alerts" class="alert-bell">🔔<span class="alert-dot"></span></a>
        <?php endif; ?>
        <a href="?page=logout" class="topbar-btn">↩ Déconnexion</a>
      </div>
    </header>

    <div class="page-content">

    <?php if ($page === 'dashboard'): ?>
    <!-- ============= DASHBOARD ============= -->
    <div class="stat-grid">
      <div class="stat-card blue">
        <div class="stat-label">Total Switches</div>
        <div class="stat-value"><?= $stats['total'] ?></div>
        <div class="stat-sub"><?= $user['org_name'] ?></div>
      </div>
      <div class="stat-card green">
        <div class="stat-label">En ligne</div>
        <div class="stat-value"><?= $stats['online'] ?></div>
        <div class="stat-sub">Opérationnels</div>
      </div>
      <div class="stat-card red">
        <div class="stat-label">Hors ligne</div>
        <div class="stat-value"><?= $stats['offline'] ?></div>
        <div class="stat-sub">Inaccessibles</div>
      </div>
      <div class="stat-card yellow">
        <div class="stat-label">En alerte</div>
        <div class="stat-value"><?= $stats['warning'] ?></div>
        <div class="stat-sub">Attention requise</div>
      </div>
    </div>

    <div class="two-col mb24">
      <!-- Switch Status Overview -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">⚡ Switches — Vue rapide</span>
          <a href="?page=switches" style="font-size:12px;color:var(--accent);text-decoration:none;">Voir tout →</a>
        </div>
        <div style="padding:8px 0;">
          <?php foreach($switches as $sw): 
            $statusClass = $sw['status'];
            $portsUp = $sw['ports_up'] ?? 0;
            $portsTotal = $sw['ports_total'] ?? 0;
          ?>
          <div style="display:flex;align-items:center;padding:10px 20px;border-bottom:1px solid rgba(30,45,71,0.4);gap:12px;">
            <div>
              <span class="status-pill <?= $statusClass ?>" style="padding:2px 8px;font-size:10px;">
                <span class="status-pulse"></span>
                <?= strtoupper($statusClass) ?>
              </span>
            </div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($sw['name']) ?></div>
              <div style="font-size:11px;color:var(--text3);font-family:var(--mono);"><?= $sw['ip_address'] ?></div>
            </div>
            <div style="text-align:right;font-size:11px;color:var(--text3);">
              <div style="font-family:var(--mono);"><?= $portsUp ?>/<?= $portsTotal ?> ports</div>
              <?php if($sw['temperature']>0): ?>
              <div style="color:<?= $sw['temperature']>=TEMP_CRITICAL?'var(--red)':($sw['temperature']>=TEMP_WARNING?'var(--yellow)':'var(--text3)') ?>">
                🌡 <?= $sw['temperature'] ?>°C
              </div>
              <?php endif; ?>
            </div>
            <a href="?page=switch_detail&id=<?= $sw['id'] ?>" class="detail-btn">→</a>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Recent Alerts -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">🔔 Alertes Récentes</span>
          <?php if(count($unreadAlerts??[])>0): ?>
          <span style="font-size:11px;background:var(--red);color:white;padding:2px 8px;border-radius:10px;"><?= count($unreadAlerts) ?> non-lues</span>
          <?php endif; ?>
        </div>
        <div class="card-body" style="padding:4px 16px;">
          <?php if(empty($alerts)): ?>
          <div style="text-align:center;color:var(--text3);padding:40px;font-size:13px;">✓ Aucune alerte active</div>
          <?php else: ?>
          <?php foreach(array_slice($alerts, 0, 6) as $alert): ?>
          <div class="alert-item" style="<?= !$alert['is_read']?'background:rgba(255,255,255,0.01)':'' ?>">
            <div class="alert-icon sev-<?= $alert['severity'] ?>">
              <?= $alert['severity']==='critical'?'🔴':($alert['severity']==='warning'?'🟡':'🔵') ?>
            </div>
            <div style="flex:1;">
              <div class="alert-title <?= !$alert['is_read']?'':''; ?>" style="<?= !$alert['is_read']?'font-weight:700':'' ?>"><?= htmlspecialchars($alert['title']) ?></div>
              <div class="alert-msg"><?= htmlspecialchars(substr($alert['message'],0,80)) ?></div>
              <div class="alert-time"><?= $alert['switch_name'] ?> • <?= date('d/m H:i', strtotime($alert['created_at'])) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php elseif ($page === 'switches'): ?>
    <!-- ============= SWITCHES LIST ============= -->
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <div>
        <div style="font-size:13px;color:var(--text3);"><?= count($switches) ?> équipements trouvés</div>
      </div>
      <?php if(Auth::is('admin')): ?>
      <button class="topbar-btn" onclick="openAddModal()" style="background:var(--accent);color:white;border-color:var(--accent);">+ Ajouter Switch</button>
      <?php endif; ?>
    </div>
    <div class="switch-grid">
      <?php foreach($switches as $sw):
        $cpuClass = $sw['cpu_usage']>=CPU_CRITICAL?'crit':($sw['cpu_usage']>=CPU_WARNING?'warn':($sw['status']==='offline'?'off':'good'));
        $tempClass = $sw['temperature']>=TEMP_CRITICAL?'crit':($sw['temperature']>=TEMP_WARNING?'warn':($sw['status']==='offline'?'off':'good'));
        $memClass = $sw['memory_usage']>=MEM_CRITICAL?'crit':($sw['memory_usage']>=MEM_WARNING?'warn':($sw['status']==='offline'?'off':'good'));
        $portsUp = $sw['ports_up'] ?? 0;
        $portsTotal = $sw['ports_total'] ?? 1;
        $portsPct = $portsTotal > 0 ? round($portsUp/$portsTotal*100) : 0;
      ?>
      <div class="switch-card status-<?= $sw['status'] ?>">
        <div class="switch-card-header">
          <div>
            <div class="switch-card-name"><?= htmlspecialchars($sw['name']) ?></div>
            <div class="switch-card-ip"><?= $sw['ip_address'] ?></div>
            <?php if($sw['hostname']): ?><div style="font-size:10px;color:var(--text3);margin-top:1px;"><?= htmlspecialchars($sw['hostname']) ?></div><?php endif; ?>
          </div>
          <span class="status-pill <?= $sw['status'] ?>">
            <span class="status-pulse"></span>
            <?= strtoupper($sw['status']) ?>
          </span>
        </div>
        <div class="switch-metrics">
          <div class="metric-item">
            <div class="metric-label">CPU</div>
            <div class="metric-value <?= $cpuClass ?>"><?= $sw['status']==='offline'?'—':$sw['cpu_usage'].'%' ?></div>
          </div>
          <div class="metric-item">
            <div class="metric-label">Mémoire</div>
            <div class="metric-value <?= $memClass ?>"><?= $sw['status']==='offline'?'—':$sw['memory_usage'].'%' ?></div>
          </div>
          <div class="metric-item">
            <div class="metric-label">Temp.</div>
            <div class="metric-value <?= $tempClass ?>"><?= $sw['status']==='offline'?'—':$sw['temperature'].'°' ?></div>
          </div>
        </div>
        <div class="switch-ports-bar">
          <div class="ports-label">
            <span>Ports actifs</span>
            <span><?= $portsUp ?>/<?= $portsTotal ?> (<?= $portsPct ?>%)</span>
          </div>
          <div class="ports-track">
            <div class="ports-track-fill" style="width:<?= $portsPct ?>%;background:<?= $portsPct<50?'var(--red)':($portsPct<80?'var(--yellow)':'var(--green)') ?>"></div>
          </div>
        </div>
        <div class="switch-card-footer">
          <div>
            <div class="switch-meta"><?= htmlspecialchars($sw['vendor']??'') ?> <?= htmlspecialchars($sw['model']??'') ?></div>
            <div class="switch-location">📍 <?= htmlspecialchars($sw['location']??'—') ?></div>
          </div>
          <div style="display:flex;gap:6px;align-items:center;">
            <?php if($sw['unread_alerts']>0): ?>
            <span class="nav-badge"><?= $sw['unread_alerts'] ?></span>
            <?php endif; ?>
            <a href="?page=switch_detail&id=<?= $sw['id'] ?>" class="detail-btn">Détail →</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <?php elseif ($page === 'switch_detail' && $selectedSwitch): ?>
    <!-- ============= SWITCH DETAIL ============= -->
    <a href="?page=switches" class="back-btn">← Retour aux switches</a>

    <div class="detail-header mb24">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px;">
        <div>
          <div class="detail-name"><?= htmlspecialchars($selectedSwitch['name']) ?></div>
          <div class="detail-sub"><?= $selectedSwitch['ip_address'] ?> • <?= htmlspecialchars($selectedSwitch['hostname']??'') ?></div>
          <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">
            <span class="status-pill <?= $selectedSwitch['status'] ?>">
              <span class="status-pulse"></span>
              <?= strtoupper($selectedSwitch['status']) ?>
            </span>
            <?php if($selectedSwitch['vendor']): ?>
            <span style="font-size:12px;background:var(--bg3);padding:3px 10px;border-radius:4px;color:var(--text2);">
              <?= htmlspecialchars($selectedSwitch['vendor']) ?>
            </span>
            <?php endif; ?>
            <?php if($selectedSwitch['model']): ?>
            <span style="font-size:12px;background:var(--bg3);padding:3px 10px;border-radius:4px;color:var(--text2);font-family:var(--mono);">
              <?= htmlspecialchars($selectedSwitch['model']) ?>
            </span>
            <?php endif; ?>
          </div>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="topbar-btn" onclick="pingSwitch(<?= $selectedSwitch['id'] ?>)">📡 Ping</button>
          <?php if(Auth::is('admin')): ?>
          <button class="topbar-btn" onclick="openEditModal()">✏ Modifier</button>
          <?php endif; ?>
        </div>
      </div>

      <!-- Live Metrics -->
      <div class="detail-grid mt16" id="live-metrics">
        <?php
        $metrics = SwitchMonitor::getMetrics($selectedSwitch);
        $cpuPct = $metrics['cpu'];
        $memPct = $metrics['memory'];
        $temp = $metrics['temperature'];
        $cpuColor = $cpuPct>=CPU_CRITICAL?'var(--red)':($cpuPct>=CPU_WARNING?'var(--yellow)':'var(--green)');
        $memColor = $memPct>=MEM_CRITICAL?'var(--red)':($memPct>=MEM_WARNING?'var(--yellow)':'var(--green)');
        $tempColor = $temp>=TEMP_CRITICAL?'var(--red)':($temp>=TEMP_WARNING?'var(--yellow)':'var(--green)');
        ?>
        <div class="live-metric">
          <div class="live-metric-label">Utilisation CPU</div>
          <div class="live-metric-value" id="cpu-val" style="color:<?= $cpuColor ?>"><?= $selectedSwitch['status']==='offline'?'—':$cpuPct ?><span class="live-metric-unit"><?= $selectedSwitch['status']!=='offline'?'%':'' ?></span></div>
          <div class="gauge-bar"><div class="gauge-fill" id="cpu-bar" style="width:<?= $cpuPct ?>%;background:<?= $cpuColor ?>"></div></div>
        </div>
        <div class="live-metric">
          <div class="live-metric-label">Mémoire RAM</div>
          <div class="live-metric-value" id="mem-val" style="color:<?= $memColor ?>"><?= $selectedSwitch['status']==='offline'?'—':$memPct ?><span class="live-metric-unit"><?= $selectedSwitch['status']!=='offline'?'%':'' ?></span></div>
          <div class="gauge-bar"><div class="gauge-fill" id="mem-bar" style="width:<?= $memPct ?>%;background:<?= $memColor ?>"></div></div>
        </div>
        <div class="live-metric">
          <div class="live-metric-label">Température</div>
          <div class="live-metric-value" id="temp-val" style="color:<?= $tempColor ?>"><?= $selectedSwitch['status']==='offline'?'—':$temp ?><span class="live-metric-unit"><?= $selectedSwitch['status']!=='offline'?'°C':'' ?></span></div>
          <div class="gauge-bar"><div class="gauge-fill" id="temp-bar" style="width:<?= min(100, ($temp/90*100)) ?>%;background:<?= $tempColor ?>"></div></div>
        </div>
      </div>
    </div>

    <div class="two-col mb24">
      <!-- Switch Info -->
      <div class="card">
        <div class="card-header"><span class="card-title">ℹ Informations</span></div>
        <div class="card-body">
          <table class="info-table">
            <tr><td>Nom</td><td><?= htmlspecialchars($selectedSwitch['name']) ?></td></tr>
            <tr><td>Hostname</td><td><?= htmlspecialchars($selectedSwitch['hostname']??'—') ?></td></tr>
            <tr><td>Adresse IP</td><td><?= $selectedSwitch['ip_address'] ?></td></tr>
            <tr><td>MAC Address</td><td><?= $selectedSwitch['mac_address']??'—' ?></td></tr>
            <tr><td>Vendeur</td><td><?= htmlspecialchars($selectedSwitch['vendor']??'—') ?></td></tr>
            <tr><td>Modèle</td><td><?= htmlspecialchars($selectedSwitch['model']??'—') ?></td></tr>
            <tr><td>Firmware</td><td><?= htmlspecialchars($selectedSwitch['firmware_version']??'—') ?></td></tr>
            <tr><td>S/N</td><td><?= htmlspecialchars($selectedSwitch['serial_number']??'—') ?></td></tr>
            <tr><td>Localisation</td><td><?= htmlspecialchars($selectedSwitch['location']??'—') ?></td></tr>
            <tr><td>Nombre de ports</td><td><?= $selectedSwitch['num_ports'] ?></td></tr>
            <tr><td>SNMP</td><td><?= $selectedSwitch['snmp_version'] ?> (community: <?= $selectedSwitch['snmp_community'] ?>)</td></tr>
            <tr><td>Uptime</td><td id="uptime-val"><?= SwitchMonitor::formatUptime($selectedSwitch['uptime_seconds']) ?></td></tr>
            <tr><td>Dernière vue</td><td><?= $selectedSwitch['last_seen'] ? date('d/m/Y H:i:s', strtotime($selectedSwitch['last_seen'])) : '—' ?></td></tr>
          </table>
          <?php if($selectedSwitch['notes']): ?>
          <div style="margin-top:12px;padding:10px;background:var(--bg3);border-radius:6px;font-size:12px;color:var(--text2);">
            📝 <?= htmlspecialchars($selectedSwitch['notes']) ?>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Protocols -->
      <div class="card">
        <div class="card-header"><span class="card-title">⟳ Protocoles Actifs</span></div>
        <div class="card-body">
          <?php if(empty($selectedProtocols)): ?>
          <div style="color:var(--text3);font-size:13px;">Aucun protocole enregistré</div>
          <?php else: ?>
          <div class="proto-grid">
            <?php foreach($selectedProtocols as $proto): ?>
            <div class="proto-badge proto-<?= $proto['status'] ?>">
              <span class="proto-dot"></span>
              <?= htmlspecialchars($proto['protocol_name']) ?>
              <?php if($proto['protocol_version']): ?>
              <span style="opacity:0.6;font-size:10px;"><?= htmlspecialchars($proto['protocol_version']) ?></span>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <div style="margin-top:16px;">
            <div class="section-title">Résumé</div>
            <?php
            $enabled = array_filter($selectedProtocols, fn($p) => $p['status'] === 'enabled');
            $disabled = array_filter($selectedProtocols, fn($p) => $p['status'] === 'disabled');
            ?>
            <div style="display:flex;gap:16px;font-size:12px;color:var(--text2);">
              <span style="color:var(--green);">● <?= count($enabled) ?> activés</span>
              <span style="color:var(--text3);">○ <?= count($disabled) ?> désactivés</span>
            </div>
          </div>
          <?php endif; ?>
        </div>

        <?php if(!empty($selectedAlerts??[])): ?>
        <div class="card-header" style="border-top:1px solid var(--border)"><span class="card-title">🔔 Alertes</span></div>
        <div class="card-body" style="padding:8px 16px;">
          <?php foreach(array_slice($selectedAlerts, 0, 4) as $alert): ?>
          <div class="alert-item">
            <span class="alert-icon sev-<?= $alert['severity'] ?>"><?= $alert['severity']==='critical'?'🔴':($alert['severity']==='warning'?'🟡':'🔵') ?></span>
            <div>
              <div class="alert-title" style="font-size:12px;"><?= htmlspecialchars($alert['title']) ?></div>
              <div class="alert-time"><?= date('d/m H:i', strtotime($alert['created_at'])) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Ports Table -->
    <div class="card mb24">
      <div class="card-header">
        <span class="card-title">🔌 Ports (<?= count($selectedPorts) ?>)</span>
        <div style="display:flex;gap:8px;font-size:11px;">
          <?php
          $up = array_filter($selectedPorts, fn($p) => $p['status'] === 'up');
          $down = array_filter($selectedPorts, fn($p) => $p['status'] === 'down');
          $disabled = array_filter($selectedPorts, fn($p) => $p['status'] === 'disabled');
          ?>
          <span style="color:var(--green);">● <?= count($up) ?> UP</span>
          <span style="color:var(--red);">● <?= count($down) ?> DOWN</span>
          <span style="color:var(--text3);">○ <?= count($disabled) ?> OFF</span>
        </div>
      </div>
      <?php if(empty($selectedPorts)): ?>
      <div style="padding:40px;text-align:center;color:var(--text3);font-size:13px;">Aucun port enregistré</div>
      <?php else: ?>
      <div style="overflow-x:auto;">
        <table class="ports-table">
          <thead>
            <tr>
              <th>#</th><th>Port</th><th>Description</th><th>Statut</th>
              <th>Vitesse</th><th>VLAN</th><th>Type</th><th>Appareil connecté</th>
              <th>Traffic IN</th><th>Traffic OUT</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($selectedPorts as $port): ?>
            <tr>
              <td class="port-number"><?= $port['port_number'] ?></td>
              <td class="port-name"><?= htmlspecialchars($port['port_name']??'') ?></td>
              <td style="font-size:12px;color:var(--text2);"><?= htmlspecialchars($port['description']??'—') ?></td>
              <td>
                <span class="port-status-dot port-<?= $port['status'] ?>"></span>
                <span style="font-size:11px;font-weight:600;color:<?= $port['status']==='up'?'var(--green)':($port['status']==='down'?'var(--red)':'var(--text3)') ?>">
                  <?= strtoupper($port['status']) ?>
                </span>
              </td>
              <td style="font-family:var(--mono);font-size:12px;"><?= $port['speed']??'—' ?></td>
              <td style="font-family:var(--mono);font-size:12px;color:var(--accent);"><?= $port['vlan_id'] ?></td>
              <td>
                <span style="font-size:10px;padding:2px 6px;border-radius:3px;background:var(--bg3);color:var(--text2);">
                  <?= strtoupper($port['port_type']??'') ?>
                </span>
              </td>
              <td style="font-size:12px;color:var(--text2);"><?= htmlspecialchars($port['connected_device']??'—') ?></td>
              <td style="font-family:var(--mono);font-size:11px;color:var(--green);"><?= SwitchMonitor::formatBytes($port['bytes_in']) ?></td>
              <td style="font-family:var(--mono);font-size:11px;color:var(--cyan);"><?= SwitchMonitor::formatBytes($port['bytes_out']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <?php elseif ($page === 'alerts'): ?>
    <!-- ============= ALERTS PAGE ============= -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">🔔 Toutes les Alertes</span>
        <span style="font-size:11px;color:var(--text3);"><?= count($alerts) ?> alertes actives</span>
      </div>
      <div class="card-body" style="padding:0;">
        <?php if(empty($alerts)): ?>
        <div style="padding:60px;text-align:center;color:var(--text3);">
          <div style="font-size:32px;margin-bottom:12px;">✅</div>
          <div>Aucune alerte active — Tout fonctionne correctement</div>
        </div>
        <?php else: ?>
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Sévérité</th>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Titre</th>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Switch</th>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Message</th>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Date</th>
              <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);">Statut</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($alerts as $alert): ?>
            <tr style="<?= !$alert['is_read']?'background:rgba(255,255,255,0.015)':'' ?>">
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);">
                <span style="display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:4px;font-size:11px;font-weight:700;text-transform:uppercase;
                  background:<?= $alert['severity']==='critical'?'rgba(255,61,113,0.12)':($alert['severity']==='warning'?'rgba(255,170,0,0.12)':'rgba(0,174,255,0.12)') ?>;
                  color:<?= $alert['severity']==='critical'?'var(--red)':($alert['severity']==='warning'?'var(--yellow)':'var(--accent)') ?>;">
                  <?= strtoupper($alert['severity']) ?>
                </span>
              </td>
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);font-weight:<?= !$alert['is_read']?'600':'400' ?>;">
                <?= htmlspecialchars($alert['title']) ?>
              </td>
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);font-family:var(--mono);font-size:12px;color:var(--accent);">
                <?= htmlspecialchars($alert['switch_name']??'—') ?>
              </td>
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);color:var(--text2);font-size:12px;max-width:300px;">
                <?= htmlspecialchars(substr($alert['message'],0,100)) ?>
              </td>
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);font-family:var(--mono);font-size:11px;color:var(--text3);">
                <?= date('d/m/Y H:i', strtotime($alert['created_at'])) ?>
              </td>
              <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);">
                <?php if(!$alert['is_read']): ?>
                <span style="font-size:10px;font-weight:700;color:var(--accent);background:rgba(0,174,255,0.1);padding:2px 8px;border-radius:4px;">NOUVEAU</span>
                <?php else: ?>
                <span style="font-size:10px;color:var(--text3);">Lu</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>

    <?php elseif ($page === 'organizations' && $user['role'] === 'superadmin'): ?>
    <!-- ============= ORGANIZATIONS ============= -->
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <div style="font-size:13px;color:var(--text3);"><?= count($organizations) ?> organisations</div>
      <button class="topbar-btn" style="background:var(--accent);color:white;border-color:var(--accent);">+ Nouvelle Org.</button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:16px;">
      <?php foreach($organizations as $org): 
        $orgSwitches = Database::fetch("SELECT COUNT(*) as cnt FROM switches WHERE organization_id = ?", [$org['id']]);
        $orgUsers = Database::fetch("SELECT COUNT(*) as cnt FROM users WHERE organization_id = ?", [$org['id']]);
      ?>
      <div class="org-card">
        <div class="org-logo">🏢</div>
        <div style="flex:1;">
          <div style="font-size:15px;font-weight:600;margin-bottom:4px;"><?= htmlspecialchars($org['name']) ?></div>
          <div style="font-size:11px;color:var(--text3);font-family:var(--mono);margin-bottom:8px;"><?= $org['slug'] ?></div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <span class="plan-badge plan-<?= $org['subscription_plan'] ?>"><?= strtoupper($org['subscription_plan']) ?></span>
            <span style="font-size:11px;color:var(--text3);">🔀 <?= $orgSwitches['cnt'] ?> switches</span>
            <span style="font-size:11px;color:var(--text3);">👤 <?= $orgUsers['cnt'] ?> users</span>
          </div>
        </div>
        <button class="detail-btn">Gérer</button>
      </div>
      <?php endforeach; ?>
    </div>

    <?php elseif ($page === 'topology'): ?>
    <!-- ============= TOPOLOGY ============= -->
    <div class="card">
      <div class="card-header"><span class="card-title">◈ Topologie Réseau</span></div>
      <div class="card-body" style="min-height:400px;">
        <canvas id="topology-canvas" width="800" height="450" style="width:100%;background:var(--bg3);border-radius:6px;"></canvas>
      </div>
    </div>
    <script>
    (function() {
      const canvas = document.getElementById('topology-canvas');
      const ctx = canvas.getContext('2d');
      const switches = <?= json_encode(array_map(fn($s) => ['id'=>$s['id'],'name'=>$s['name'],'status'=>$s['status'],'num_ports'=>$s['num_ports']], $switches)) ?>;
      
      const colors = { online:'#00d68f', offline:'#ff3d71', warning:'#ffaa00', unknown:'#8f9bb3' };
      
      function drawTopology() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw grid
        ctx.strokeStyle = 'rgba(30,45,71,0.5)';
        ctx.lineWidth = 0.5;
        for(let x = 0; x < canvas.width; x += 40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,canvas.height); ctx.stroke(); }
        for(let y = 0; y < canvas.height; y += 40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y); ctx.stroke(); }
        
        if(!switches.length) { ctx.fillStyle='#4e6585'; ctx.font='14px IBM Plex Mono'; ctx.fillText('Aucun switch disponible', 300, 225); return; }
        
        const positions = [];
        const cx = canvas.width/2, cy = canvas.height/2;
        
        // Place core switch in center, others around
        switches.forEach((sw, i) => {
          let x, y;
          if(i === 0) { x = cx; y = cy; }
          else {
            const angle = ((i-1) / (switches.length-1)) * Math.PI * 2;
            const r = 160;
            x = cx + Math.cos(angle) * r;
            y = cy + Math.sin(angle) * r;
          }
          positions.push({...sw, x, y});
        });
        
        // Draw links from center to others
        positions.slice(1).forEach(sw => {
          const core = positions[0];
          const grad = ctx.createLinearGradient(core.x, core.y, sw.x, sw.y);
          grad.addColorStop(0, 'rgba(0,174,255,0.5)');
          grad.addColorStop(1, `${colors[sw.status]}40`);
          ctx.beginPath();
          ctx.strokeStyle = grad;
          ctx.lineWidth = sw.status === 'offline' ? 1 : 2;
          ctx.setLineDash(sw.status === 'offline' ? [4,4] : []);
          ctx.moveTo(core.x, core.y);
          ctx.lineTo(sw.x, sw.y);
          ctx.stroke();
          ctx.setLineDash([]);
        });
        
        // Draw nodes
        positions.forEach((sw, i) => {
          const r = i === 0 ? 30 : 22;
          ctx.beginPath();
          ctx.arc(sw.x, sw.y, r, 0, Math.PI*2);
          ctx.fillStyle = i === 0 ? 'rgba(0,174,255,0.15)' : `${colors[sw.status]}15`;
          ctx.fill();
          ctx.strokeStyle = i === 0 ? '#00aeff' : colors[sw.status];
          ctx.lineWidth = 2;
          ctx.stroke();
          
          ctx.fillStyle = '#00aeff';
          ctx.font = `${i===0?'14':'11'}px IBM Plex Mono`;
          ctx.textAlign = 'center';
          ctx.fillText('SW', sw.x, sw.y + 4);
          
          ctx.fillStyle = '#e2eaf8';
          ctx.font = '10px IBM Plex Sans';
          const label = sw.name.length > 14 ? sw.name.substring(0,13)+'…' : sw.name;
          ctx.fillText(label, sw.x, sw.y + r + 14);
          
          // Status dot
          ctx.beginPath();
          ctx.arc(sw.x + r - 4, sw.y - r + 4, 5, 0, Math.PI*2);
          ctx.fillStyle = colors[sw.status];
          ctx.fill();
        });
      }
      
      drawTopology();
    })();
    </script>

    <?php elseif ($page === 'protocols'): ?>
    <!-- ============= PROTOCOLS ============= -->
    <?php
    $allProtos = Database::fetchAll(
        "SELECT sp.*, s.name as switch_name, s.ip_address FROM switch_protocols sp 
         JOIN switches s ON sp.switch_id = s.id WHERE s.organization_id = ? ORDER BY sp.protocol_name, s.name",
        [$user['org_id']]
    );
    $byProto = [];
    foreach($allProtos as $p) {
        $byProto[$p['protocol_name']][] = $p;
    }
    ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;">
      <?php foreach($byProto as $protoName => $instances): 
        $enabledCount = count(array_filter($instances, fn($p) => $p['status']==='enabled'));
      ?>
      <div class="card">
        <div class="card-header">
          <span class="card-title"><?= htmlspecialchars($protoName) ?></span>
          <span style="font-size:11px;color:<?= $enabledCount>0?'var(--green)':'var(--text3)' ?>">
            <?= $enabledCount ?>/<?= count($instances) ?> activés
          </span>
        </div>
        <div class="card-body" style="padding:8px 16px;">
          <?php foreach($instances as $inst): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(30,45,71,0.4);">
            <div>
              <div style="font-size:13px;font-weight:500;"><?= htmlspecialchars($inst['switch_name']) ?></div>
              <div style="font-size:11px;color:var(--text3);font-family:var(--mono);"><?= $inst['ip_address'] ?></div>
            </div>
            <div style="text-align:right;">
              <span class="proto-badge proto-<?= $inst['status'] ?>" style="font-size:10px;padding:3px 8px;">
                <span class="proto-dot"></span>
                <?= strtoupper($inst['status']) ?>
              </span>
              <?php if($inst['protocol_version']): ?>
              <div style="font-size:9px;color:var(--text3);font-family:var(--mono);margin-top:2px;"><?= htmlspecialchars($inst['protocol_version']) ?></div>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <?php elseif ($page === 'users'): ?>
    <!-- ============= USERS PAGE ============= -->
    <?php
    $users = Database::fetchAll(
        "SELECT u.*, o.name as org_name FROM users u LEFT JOIN organizations o ON u.organization_id = o.id 
         WHERE u.organization_id = ? ORDER BY u.role DESC, u.full_name",
        [$user['org_id']]
    );
    ?>
    <div class="card">
      <div class="card-header">
        <span class="card-title">👤 Utilisateurs</span>
        <span style="font-size:12px;color:var(--text3);"><?= count($users) ?> comptes</span>
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
          <tr>
            <?php foreach(['Utilisateur','Email','Rôle','Dernière connexion','Statut'] as $h): ?>
            <th style="padding:12px 16px;text-align:left;font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.7px;border-bottom:1px solid var(--border);"><?= $h ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach($users as $u): ?>
          <tr>
            <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);">
              <div style="display:flex;align-items:center;gap:10px;">
                <div class="user-avatar" style="width:28px;height:28px;font-size:11px;"><?= strtoupper(substr($u['full_name'],0,1)) ?></div>
                <div>
                  <div style="font-weight:600;"><?= htmlspecialchars($u['full_name']) ?></div>
                  <div style="font-size:11px;color:var(--text3);font-family:var(--mono);">@<?= htmlspecialchars($u['username']) ?></div>
                </div>
              </div>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);font-size:12px;color:var(--text2);"><?= htmlspecialchars($u['email']) ?></td>
            <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);">
              <span class="role-badge role-<?= $u['role'] ?>"><?= strtoupper($u['role']) ?></span>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);font-family:var(--mono);font-size:11px;color:var(--text3);">
              <?= $u['last_login'] ? date('d/m/Y H:i', strtotime($u['last_login'])) : 'Jamais' ?>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid rgba(30,45,71,0.5);">
              <span style="font-size:11px;font-weight:600;color:<?= $u['is_active']?'var(--green)':'var(--red)' ?>">
                <?= $u['is_active']?'● Actif':'○ Inactif' ?>
              </span>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php elseif ($page === 'settings'): ?>
    <!-- ============= SETTINGS ============= -->
    <div class="two-col">
      <div class="card">
        <div class="card-header"><span class="card-title">⚙ Paramètres Monitoring</span></div>
        <div class="card-body">
          <?php $settingsRows = [['Intervalle de vérification','60 secondes'],['Timeout Ping','3 secondes'],['Seuil CPU Warning',CPU_WARNING.'%'],['Seuil CPU Critique',CPU_CRITICAL.'%'],['Seuil Temp Warning',TEMP_WARNING.'°C'],['Seuil Temp Critique',TEMP_CRITICAL.'°C'],['Seuil RAM Warning',MEM_WARNING.'%'],['Seuil RAM Critique',MEM_CRITICAL.'%'],['Session Timeout','60 minutes']]; ?>
          <table class="info-table">
            <?php foreach($settingsRows as [$label, $val]): ?>
            <tr><td><?= $label ?></td><td><?= $val ?></td></tr>
            <?php endforeach; ?>
          </table>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">🏢 Organisation</span></div>
        <div class="card-body">
          <?php $org = Database::fetch("SELECT * FROM organizations WHERE id = ?", [$user['org_id']]); ?>
          <?php if($org): ?>
          <table class="info-table">
            <tr><td>Nom</td><td><?= htmlspecialchars($org['name']) ?></td></tr>
            <tr><td>Slug</td><td><?= htmlspecialchars($org['slug']) ?></td></tr>
            <tr><td>Email</td><td><?= htmlspecialchars($org['contact_email']??'—') ?></td></tr>
            <tr><td>Plan</td><td><span class="plan-badge plan-<?= $org['subscription_plan'] ?>"><?= strtoupper($org['subscription_plan']) ?></span></td></tr>
            <tr><td>Créé le</td><td><?= date('d/m/Y', strtotime($org['created_at'])) ?></td></tr>
          </table>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    </div><!-- /page-content -->
  </div><!-- /main-content -->
</div><!-- /app-layout -->

<!-- Add Switch Modal -->
<div class="modal-overlay" id="add-modal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">➕ Ajouter un Switch</span>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="two-col">
        <div class="form-group">
          <label class="form-label">Nom *</label>
          <input type="text" id="sw-name" class="form-input" placeholder="Core-Switch-01">
        </div>
        <div class="form-group">
          <label class="form-label">Adresse IP *</label>
          <input type="text" id="sw-ip" class="form-input" placeholder="192.168.1.10">
        </div>
      </div>
      <div class="two-col">
        <div class="form-group">
          <label class="form-label">Vendeur</label>
          <input type="text" id="sw-vendor" class="form-input" placeholder="Cisco">
        </div>
        <div class="form-group">
          <label class="form-label">Modèle</label>
          <input type="text" id="sw-model" class="form-input" placeholder="Catalyst 9300">
        </div>
      </div>
      <div class="two-col">
        <div class="form-group">
          <label class="form-label">Localisation</label>
          <input type="text" id="sw-location" class="form-input" placeholder="Datacenter Rack 2">
        </div>
        <div class="form-group">
          <label class="form-label">Nombre de ports</label>
          <input type="number" id="sw-ports" class="form-input" value="24" min="1" max="512">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Notes</label>
        <input type="text" id="sw-notes" class="form-input" placeholder="Notes optionnelles...">
      </div>
      <button class="btn-primary" onclick="saveSwitch()">💾 Enregistrer</button>
    </div>
  </div>
</div>

<?php endif; ?>

<script>
// ---- PING ----
async function pingSwitch(id) {
  const btn = event.target;
  btn.textContent = '⏳ Ping...';
  btn.disabled = true;
  try {
    const r = await fetch(`api/switches.php?action=ping&id=${id}`);
    const d = await r.json();
    if(d.reachable) {
      alert(`✅ ${d.ip} est joignable\nTemps de réponse: ${d.response_ms}ms`);
    } else {
      alert(`❌ ${d.ip} est INJOIGNABLE`);
    }
  } catch(e) { alert('Erreur de communication'); }
  btn.textContent = '📡 Ping';
  btn.disabled = false;
}

// ---- LIVE METRICS REFRESH ----
<?php if($page === 'switch_detail' && $selectedSwitch && $selectedSwitch['status'] !== 'offline'): ?>
setInterval(async () => {
  try {
    const r = await fetch('api/switches.php?action=live_metrics&id=<?= $selectedSwitch['id'] ?>');
    const d = await r.json();
    if(d.error) return;
    const updateMetric = (valId, barId, val, max, warn, crit) => {
      const color = val>=crit?'#ff3d71':val>=warn?'#ffaa00':'#00d68f';
      document.getElementById(valId).innerHTML = `${val}<span class="live-metric-unit">%</span>`;
      document.getElementById(valId).style.color = color;
      if(document.getElementById(barId)) {
        document.getElementById(barId).style.width = Math.min(100,val/max*100)+'%';
        document.getElementById(barId).style.background = color;
      }
    };
    updateMetric('cpu-val','cpu-bar',d.cpu,100,<?= CPU_WARNING ?>,<?= CPU_CRITICAL ?>);
    updateMetric('mem-val','mem-bar',d.memory,100,<?= MEM_WARNING ?>,<?= MEM_CRITICAL ?>);
    const tempColor = d.temperature>=<?= TEMP_CRITICAL ?>?'#ff3d71':d.temperature>=<?= TEMP_WARNING ?>?'#ffaa00':'#00d68f';
    const tv = document.getElementById('temp-val');
    if(tv) { tv.innerHTML = `${d.temperature}<span class="live-metric-unit">°C</span>`; tv.style.color = tempColor; }
    const tb = document.getElementById('temp-bar');
    if(tb) { tb.style.width = Math.min(100, d.temperature/90*100)+'%'; tb.style.background = tempColor; }
    const uv = document.getElementById('uptime-val');
    if(uv && d.uptime_formatted) uv.textContent = d.uptime_formatted;
  } catch(e) {}
}, 8000);
<?php endif; ?>

// ---- MODAL ----
function openAddModal() { document.getElementById('add-modal').classList.add('open'); }
function openEditModal() { document.getElementById('add-modal').classList.add('open'); }
function closeModal() { document.getElementById('add-modal').classList.remove('open'); }
document.getElementById('add-modal')?.addEventListener('click', e => { if(e.target === e.currentTarget) closeModal(); });

async function saveSwitch() {
  const data = {
    name: document.getElementById('sw-name').value,
    ip_address: document.getElementById('sw-ip').value,
    vendor: document.getElementById('sw-vendor').value,
    model: document.getElementById('sw-model').value,
    location: document.getElementById('sw-location').value,
    num_ports: document.getElementById('sw-ports').value,
    notes: document.getElementById('sw-notes').value,
  };
  if(!data.name || !data.ip_address) { alert('Nom et IP obligatoires'); return; }
  try {
    const r = await fetch('api/switches.php?action=save_switch', {
      method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)
    });
    const d = await r.json();
    if(d.success) { closeModal(); window.location.reload(); }
    else alert('Erreur: ' + (d.error||'Inconnue'));
  } catch(e) { alert('Erreur réseau'); }
}
</script>

</body>
</html>
